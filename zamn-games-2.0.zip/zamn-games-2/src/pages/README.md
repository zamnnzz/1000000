سيتم فصل HomePage وGamePage وBlogPage وArticlePage هنا في المرحلة التالية.
