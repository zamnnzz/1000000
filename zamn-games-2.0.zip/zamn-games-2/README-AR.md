# ألعاب زامن 2.0

هذه نسخة إعادة هيكلة مبنية من ملفات الموقع المرفوعة.

## ما تم فصله
- `src/data/games.js`: بيانات الألعاب
- `src/data/articles.js`: المقالات
- `src/data/faq.js`: الأسئلة الشائعة
- `src/services/firebase.js`: Firebase والتحليلات
- `src/seo/gameSeo.js`: عناوين وأوصاف صفحات الألعاب
- `src/App.jsx`: الواجهة الحالية (مرحلة توافق أولى)
- `src/styles.css`: Tailwind + CSS الأصلي

## التشغيل
```bash
npm install
npm run dev
```

## البناء
```bash
npm run build
```

على Vercel: Framework = Vite، Build Command = `npm run build`، Output = `dist`.

ملاحظة: لم تُقسّم واجهة App الكبيرة إلى Components/Pages بعد، حتى نحافظ أولًا على نفس السلوك. المجلدات جاهزة للمرحلة التالية.
